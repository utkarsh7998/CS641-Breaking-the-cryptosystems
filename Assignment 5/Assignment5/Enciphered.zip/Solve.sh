#!/bin/bash

python3 assignment5.py

echo "Assignment completed"
