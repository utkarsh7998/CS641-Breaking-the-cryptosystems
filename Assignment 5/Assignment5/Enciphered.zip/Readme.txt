Python version: 3
Environment(base): conda


Libraries needed:
numpy
pyfinite
pexpect


Steps to run the assignment:- 
Step 1: Unzip Enciphered.zip in your local folder.
Step 2: Open terminal in the same folder where file has been extracted.
Step 3: Run the command, "make run" and wait for the terminal to show the password in some minutes.
Step 4: The output shown is the final password to clear level 5.

NOTE:

1. The assignment runs by pinging server continuously. Hence, it may take a large amount of time to run (~approx 5-10 minutes or more) depending on the internet speed.

2. The assignment has been developed in a Linux Ubuntu Operating System. 
